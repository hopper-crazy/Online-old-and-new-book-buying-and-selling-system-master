package com.onlineBookStore.BooksStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
